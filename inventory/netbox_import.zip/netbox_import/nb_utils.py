"""
Shared utilities for all NetBox import scripts.
"""

import re
import sys
import yaml
import requests
import ipaddress
import pandas as pd
from pathlib import Path
from typing import Optional


# ── Config loading ─────────────────────────────────────────────────────────────

def load_config(mapping_file: str = "mapping.yaml") -> dict:
    path = Path(mapping_file)
    if not path.exists():
        sys.exit(f"[ERROR] Mapping file not found: {mapping_file}")
    with open(path) as f:
        cfg = yaml.safe_load(f)
    required = ["excel", "fields", "netbox", "kind_column", "device_value", "vm_value"]
    for key in required:
        if key not in cfg:
            sys.exit(f"[ERROR] mapping.yaml is missing required key: '{key}'")
    return cfg


# ── Excel loading ──────────────────────────────────────────────────────────────

def load_excel(excel_file: str, cfg: dict) -> pd.DataFrame:
    sheet  = cfg["excel"]["sheet_name"]
    header = cfg["excel"]["header_row"] - 1   # pandas is 0-indexed
    try:
        df = pd.read_excel(excel_file, sheet_name=sheet, header=header)
    except Exception as e:
        sys.exit(f"[ERROR] Cannot read '{excel_file}' sheet '{sheet}': {e}")
    df.columns = df.columns.str.strip()
    # Drop the merged title row that sometimes bleeds in as a data row
    df = df[df.iloc[:, 0].notna()].copy()
    df = df[~df.iloc[:, 0].astype(str).str.startswith("Consolidated Device Inventory")].copy()
    df = df.reset_index(drop=True)
    print(f"[INFO] Loaded {len(df)} rows from '{sheet}' in '{excel_file}'")
    return df


# ── Row classification ─────────────────────────────────────────────────────────

def get_kind(row: pd.Series, cfg: dict) -> Optional[str]:
    """Return 'device', 'vm', or None (skip)."""
    col = cfg["kind_column"]
    if col not in row.index:
        return None
    val = str(row[col]).strip().lower()
    if val == str(cfg["device_value"]).lower():
        return "device"
    if val == str(cfg["vm_value"]).lower():
        return "vm"
    extras = [str(v).lower() for v in cfg.get("extra_device_values", [])]
    if val in extras:
        return "device"
    return None


# ── Value helpers ──────────────────────────────────────────────────────────────

def cell(row: pd.Series, column_name: str) -> str:
    """Safely get a cell value as a clean string."""
    if not column_name or column_name not in row.index:
        return ""
    v = row[column_name]
    if pd.isna(v):
        return ""
    s = str(v).strip()
    return "" if s.lower() in ("nan", "none", "nat", "") else s


def parse_ips(raw: str, default_prefix: str = "/24") -> list[str]:
    """
    Split comma-separated IP string, validate each, append prefix if missing.
    Returns list of CIDR strings ready for NetBox (e.g. ['10.1.1.5/24']).
    """
    results = []
    if not raw:
        return results
    for part in re.split(r"[,;\s]+", raw):
        part = part.strip()
        if not part:
            continue
        # Check if already has prefix
        if "/" in part:
            try:
                ipaddress.ip_interface(part)
                results.append(part)
            except ValueError:
                print(f"  [WARN] Invalid IP skipped: {part}")
        else:
            try:
                ipaddress.ip_address(part)
                results.append(part + default_prefix)
            except ValueError:
                print(f"  [WARN] Invalid IP skipped: {part}")
    return results


# ── NetBox API client ──────────────────────────────────────────────────────────

class NetBoxAPI:
    def __init__(self, cfg: dict):
        nb = cfg["netbox"]
        self.base    = nb["url"].rstrip("/")
        self.headers = {
            "Authorization": f"Token {nb['token']}",
            "Content-Type":  "application/json",
            "Accept":        "application/json",
        }
        self.verify  = nb.get("verify_ssl", True)
        self.timeout = nb.get("timeout", 30)
        self._cache: dict[str, dict] = {}

    def _url(self, path: str) -> str:
        return f"{self.base}/api/{path.lstrip('/')}"

    def get(self, path: str, params: dict = None) -> list:
        url = self._url(path)
        results, offset = [], 0
        while True:
            p = dict(params or {})
            p.update({"limit": 100, "offset": offset})
            r = requests.get(url, headers=self.headers, params=p,
                             verify=self.verify, timeout=self.timeout)
            r.raise_for_status()
            data = r.json()
            results.extend(data.get("results", []))
            if not data.get("next"):
                break
            offset += 100
        return results

    def post(self, path: str, payload: dict) -> dict:
        r = requests.post(self._url(path), headers=self.headers,
                          json=payload, verify=self.verify, timeout=self.timeout)
        if not r.ok:
            print(f"  [ERROR] POST {path} → {r.status_code}: {r.text[:300]}")
            return {}
        return r.json()

    def patch(self, path: str, obj_id: int, payload: dict) -> dict:
        r = requests.patch(self._url(f"{path}{obj_id}/"), headers=self.headers,
                           json=payload, verify=self.verify, timeout=self.timeout)
        if not r.ok:
            print(f"  [ERROR] PATCH {path}{obj_id}/ → {r.status_code}: {r.text[:300]}")
            return {}
        return r.json()

    # -- Lookup helpers (cached) -----------------------------------------------

    def _lookup(self, endpoint: str, name: str, field: str = "name") -> Optional[int]:
        key = f"{endpoint}|{name}"
        if key in self._cache:
            return self._cache[key]
        results = self.get(endpoint, {field: name})
        if not results:
            # try slug
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
            results = self.get(endpoint, {"slug": slug})
        obj_id = results[0]["id"] if results else None
        self._cache[key] = obj_id
        return obj_id

    def get_tenant_id(self, name: str) -> Optional[int]:
        return self._lookup("tenancy/tenants/", name) if name else None

    def get_site_id(self, name: str) -> Optional[int]:
        return self._lookup("dcim/sites/", name) if name else None

    def get_role_id(self, name: str, for_vm: bool = False) -> Optional[int]:
        ep = "virtualization/cluster-types/" if for_vm else "dcim/device-roles/"
        # NetBox ≥3.3 uses a unified DeviceRole for both devices and VMs
        return self._lookup("dcim/device-roles/", name) if name else None

    def get_device_type_id(self, name: str) -> Optional[int]:
        return self._lookup("dcim/device-types/", name, field="model") if name else None

    def get_platform_id(self, name: str) -> Optional[int]:
        return self._lookup("dcim/platforms/", name) if name else None

    def get_device_id(self, name: str) -> Optional[int]:
        results = self.get("dcim/devices/", {"name": name})
        return results[0]["id"] if results else None

    def get_vm_id(self, name: str) -> Optional[int]:
        results = self.get("virtualization/virtual-machines/", {"name": name})
        return results[0]["id"] if results else None

    def get_cluster_id(self, name: str) -> Optional[int]:
        return self._lookup("virtualization/clusters/", name) if name else None

    def get_interface_id(self, device_id: int, iface_name: str) -> Optional[int]:
        results = self.get("dcim/interfaces/", {"device_id": device_id, "name": iface_name})
        return results[0]["id"] if results else None

    def get_vm_interface_id(self, vm_id: int, iface_name: str) -> Optional[int]:
        results = self.get("virtualization/interfaces/", {"virtual_machine_id": vm_id, "name": iface_name})
        return results[0]["id"] if results else None
