# NetBox Inventory Import — Usage Guide

## Overview

Three scripts that must be run **in order**. Each step depends on the previous one because NetBox requires objects to exist before they can be referenced.

```
Step 1 → Create Devices / Virtual Machines
Step 2 → Create Interfaces  (attached to the devices/VMs from step 1)
Step 3 → Create & Assign IPs (attached to the interfaces from step 2)
```

---

## Files

| File | Purpose |
|---|---|
| `mapping.yaml` | **Edit this.** Maps your Excel columns → NetBox fields |
| `nb_utils.py` | Shared utilities — do not run directly |
| `01_import_devices_vms.py` | Step 1 — Devices & VMs |
| `02_import_interfaces.py` | Step 2 — Interfaces |
| `03_import_ips.py` | Step 3 — IP Addresses |

---

## Requirements

```bash
pip install requests pandas openpyxl pyyaml
```

---

## Quick Start

### 1. Edit `mapping.yaml`

Set your NetBox URL and token:
```yaml
netbox:
  url: "https://netbox.yourcompany.com"
  token: "abc123yourtokenhere"
```

Set the column names to match your Excel sheet exactly:
```yaml
fields:
  name:
    excel_column: "Device Name"
  tenant:
    excel_column: "Tenant"
  role:
    excel_column: "Device Type"
  device_type:
    excel_column: "Product Type"
  platform:
    excel_column: "OS"
```

### 2. Prepare NetBox prerequisites

Before running the scripts, make sure these objects already exist in NetBox:
- **Tenants** — matching the values in your Tenant column
- **Device Roles** — matching the values in your Device Type column (e.g. Server, Workstation, Appliance)
- **Device Types** — matching the values in your Product Type column (e.g. Database Server, Firewall)
- **Platforms** — matching the OS values (or leave `platform` column blank to skip)
- **Sites** — at least one site must exist (set `DEFAULT_SITE` in `01_import_devices_vms.py`)
- **Clusters** — at least one cluster for VMs (set `DEFAULT_VM_CLUSTER` in `01_import_devices_vms.py`)

### 3. Dry run first (no changes made)

```bash
python 01_import_devices_vms.py inventory.xlsx --dry-run
python 02_import_interfaces.py  inventory.xlsx --dry-run
python 03_import_ips.py         inventory.xlsx --dry-run
```

### 4. Run for real

```bash
python 01_import_devices_vms.py inventory.xlsx
python 02_import_interfaces.py  inventory.xlsx
python 03_import_ips.py         inventory.xlsx
```

---

## mapping.yaml Reference

### `kind_column` — what decides Device vs VM

```yaml
kind_column: "Device Type"    # your Excel column
device_value: "Server"        # rows with this → physical Device
vm_value: "Workstation"       # rows with this → Virtual Machine
extra_device_values:          # these also become physical Devices
  - "Appliance"
  - "Unknown"
```

### `fields` — core NetBox fields

| Key | NetBox field | Notes |
|---|---|---|
| `name` | `device.name` / `vm.name` | Required |
| `tenant` | `device.tenant` / `vm.tenant` | Must exist in NetBox |
| `role` | `device.role` / `vm.role` | Must exist as DeviceRole in NetBox |
| `device_type` | `device.device_type` | **Devices only** — must exist as DeviceType in NetBox |
| `site` | `device.site` | Leave `excel_column` blank to use `DEFAULT_SITE` constant |
| `platform` | `device.platform` / `vm.platform` | Must exist as Platform in NetBox |
| `status` | `device.status` / `vm.status` | Defaults to `active` |

### `interface` — interface creation

```yaml
interface:
  name_column: ""             # leave blank to auto-generate interface name
  default_device_interface: "mgmt"   # name used for Devices when column is blank
  default_vm_interface: "eth0"       # name used for VMs when column is blank
  type: "1000base-t"          # interface type for physical Devices
```

### `ip` — IP address import

```yaml
ip:
  column: "IP Address(es)"    # Excel column (comma-separated IPs accepted)
  prefix_length: "/24"        # appended when IP has no prefix; use "" for /32
```

### `custom_fields` — extra columns → NetBox custom fields

```yaml
custom_fields:
  mac_address:  "MAC Address(es)"
  match_count:  "Match Count"
  found_in:     "Found In Inventories"
```

The key (`mac_address`) must be the **slug** of an existing custom field in NetBox.  
The value (`"MAC Address(es)"`) is the exact Excel column header.

---

## Troubleshooting

**"Device type not found in NetBox"**  
→ The value in your Product Type column doesn't match any DeviceType in NetBox.  
→ Either create the DeviceType in NetBox first, or leave the `device_type` column blank to skip it.

**"Site not found in NetBox"**  
→ Edit `DEFAULT_SITE` at the top of `01_import_devices_vms.py` to match an existing site slug/name.

**"Cluster not found in NetBox"**  
→ Edit `DEFAULT_VM_CLUSTER` at the top of `01_import_devices_vms.py` to match an existing cluster.

**"run step 1 first" / "run step 2 first"**  
→ Steps must be run in order: 01 → 02 → 03.

**SSL errors**  
→ Set `verify_ssl: false` in `mapping.yaml` if using a self-signed certificate.

**Idempotent re-runs**  
→ All three scripts are safe to re-run. Existing objects are detected and skipped.
