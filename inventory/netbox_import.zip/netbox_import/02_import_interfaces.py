#!/usr/bin/env python3
"""
Step 2 — Create Interfaces on Devices and Virtual Machines.

Run AFTER step 1 (devices/VMs must already exist in NetBox).
Run BEFORE step 3 (IPs are assigned to interfaces).

Usage:
    python 02_import_interfaces.py <excel_file> [--mapping mapping.yaml] [--dry-run]
"""

import sys
import argparse
from nb_utils import load_config, load_excel, get_kind, cell, NetBoxAPI


def iface_name_for_row(row, cfg) -> str:
    """Return the interface name to use for this row."""
    iface_cfg  = cfg.get("interface", {})
    name_col   = iface_cfg.get("name_column", "")
    val        = cell(row, name_col) if name_col else ""
    if val:
        return val
    kind = get_kind(row, cfg)
    if kind == "vm":
        return iface_cfg.get("default_vm_interface", "eth0")
    return iface_cfg.get("default_device_interface", "mgmt")


def create_device_interface(device_id: int, iface_name: str, iface_type: str,
                             nb: NetBoxAPI, dry_run: bool) -> bool:
    existing = nb.get_interface_id(device_id, iface_name)
    if existing:
        print(f"    [SKIP] Interface '{iface_name}' already exists on device id={device_id}")
        return False

    payload = {
        "device": device_id,
        "name":   iface_name,
        "type":   iface_type or "1000base-t",
    }
    if dry_run:
        print(f"    [DRY-RUN] Would create Device interface '{iface_name}' on device id={device_id}")
        return True
    result = nb.post("dcim/interfaces/", payload)
    if result.get("id"):
        print(f"    [OK] Interface '{iface_name}' created (id={result['id']}) on device id={device_id}")
        return True
    print(f"    [FAIL] Could not create interface '{iface_name}' on device id={device_id}")
    return False


def create_vm_interface(vm_id: int, iface_name: str,
                         nb: NetBoxAPI, dry_run: bool) -> bool:
    existing = nb.get_vm_interface_id(vm_id, iface_name)
    if existing:
        print(f"    [SKIP] Interface '{iface_name}' already exists on VM id={vm_id}")
        return False

    payload = {
        "virtual_machine": vm_id,
        "name":            iface_name,
    }
    if dry_run:
        print(f"    [DRY-RUN] Would create VM interface '{iface_name}' on VM id={vm_id}")
        return True
    result = nb.post("virtualization/interfaces/", payload)
    if result.get("id"):
        print(f"    [OK] VM interface '{iface_name}' created (id={result['id']}) on VM id={vm_id}")
        return True
    print(f"    [FAIL] Could not create VM interface '{iface_name}' on VM id={vm_id}")
    return False


def main():
    parser = argparse.ArgumentParser(description="Step 2 — Create Interfaces in NetBox")
    parser.add_argument("excel_file", help="Path to the consolidated Excel inventory")
    parser.add_argument("--mapping", default="mapping.yaml", help="Path to mapping.yaml")
    parser.add_argument("--dry-run", action="store_true", help="Preview without writing")
    args = parser.parse_args()

    cfg = load_config(args.mapping)
    df  = load_excel(args.excel_file, cfg)
    nb  = NetBoxAPI(cfg)

    iface_type = cfg.get("interface", {}).get("type", "1000base-t")
    created = skipped = errors = 0

    for idx, row in df.iterrows():
        kind = get_kind(row, cfg)
        name = cell(row, cfg["fields"]["name"]["excel_column"])

        if kind is None:
            skipped += 1
            continue

        iface_name = iface_name_for_row(row, cfg)
        print(f"\n[Row {idx+1}] {name}  ({kind.upper()})  → interface: '{iface_name}'")

        if kind == "device":
            device_id = nb.get_device_id(name)
            if not device_id:
                print(f"  [ERROR] Device '{name}' not found in NetBox — run step 1 first")
                errors += 1
                continue
            ok = create_device_interface(device_id, iface_name, iface_type, nb, args.dry_run)

        else:  # vm
            vm_id = nb.get_vm_id(name)
            if not vm_id:
                print(f"  [ERROR] VM '{name}' not found in NetBox — run step 1 first")
                errors += 1
                continue
            ok = create_vm_interface(vm_id, iface_name, nb, args.dry_run)

        if ok: created += 1
        else:  skipped += 1

    print("\n" + "="*60)
    print(f"  Interfaces created : {created}")
    print(f"  Skipped/existing   : {skipped}")
    print(f"  Errors             : {errors}")
    print("="*60)
    if args.dry_run:
        print("  DRY-RUN — nothing was written to NetBox.")


if __name__ == "__main__":
    main()
