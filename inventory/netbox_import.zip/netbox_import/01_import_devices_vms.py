#!/usr/bin/env python3
"""
Step 1 — Import Devices and Virtual Machines into NetBox.

Run FIRST. Interfaces and IPs depend on this step completing.

Usage:
    python 01_import_devices_vms.py <excel_file> [--mapping mapping.yaml] [--dry-run]

Examples:
    python 01_import_devices_vms.py inventory.xlsx
    python 01_import_devices_vms.py inventory.xlsx --dry-run
    python 01_import_devices_vms.py inventory.xlsx --mapping /path/to/mapping.yaml
"""

import sys
import argparse
from nb_utils import load_config, load_excel, get_kind, cell, NetBoxAPI

# ---------------------------------------------------------------------------
# Default cluster name used when importing VMs (NetBox requires a cluster).
# Change this or add a "cluster" column to your Excel and update mapping.yaml.
DEFAULT_VM_CLUSTER = "Default"
# Default site used when no site column is mapped.
DEFAULT_SITE = "Primary Site"
# ---------------------------------------------------------------------------


def build_custom_fields(row, cfg) -> dict:
    cf = {}
    for nb_field, excel_col in cfg.get("custom_fields", {}).items():
        v = cell(row, excel_col)
        if v:
            cf[nb_field] = v
    return cf


def import_device(row, cfg, nb: NetBoxAPI, dry_run: bool) -> bool:
    f = cfg["fields"]
    name = cell(row, f["name"]["excel_column"])
    if not name:
        print("  [SKIP] Empty device name")
        return False

    # Check if already exists
    existing_id = nb.get_device_id(name)
    if existing_id:
        print(f"  [SKIP] Device already exists: {name} (id={existing_id})")
        return False

    # Resolve FK fields
    role_name    = cell(row, f.get("role", {}).get("excel_column", ""))
    dtype_name   = cell(row, f.get("device_type", {}).get("excel_column", ""))
    tenant_name  = cell(row, f.get("tenant", {}).get("excel_column", ""))
    site_name    = cell(row, f.get("site", {}).get("excel_column", "")) or DEFAULT_SITE
    platform_name = cell(row, f.get("platform", {}).get("excel_column", ""))
    status_col   = f.get("status", {}).get("excel_column", "")
    status       = cell(row, status_col) or f.get("status", {}).get("default", "active")

    role_id     = nb.get_role_id(role_name)       if role_name     else None
    dtype_id    = nb.get_device_type_id(dtype_name) if dtype_name  else None
    tenant_id   = nb.get_tenant_id(tenant_name)   if tenant_name   else None
    site_id     = nb.get_site_id(site_name)        if site_name     else None
    platform_id = nb.get_platform_id(platform_name) if platform_name else None

    if not dtype_id:
        print(f"  [WARN] Device type not found in NetBox: '{dtype_name}' — device_type will be omitted for {name}")
    if not site_id:
        print(f"  [WARN] Site not found in NetBox: '{site_name}' — site will be omitted for {name}")

    payload = {
        "name":        name,
        "status":      status.lower() if status else "active",
        "custom_fields": build_custom_fields(row, cfg),
    }
    if role_id:     payload["role"]        = role_id
    if dtype_id:    payload["device_type"] = dtype_id
    if tenant_id:   payload["tenant"]      = tenant_id
    if site_id:     payload["site"]        = site_id
    if platform_id: payload["platform"]    = platform_id

    if dry_run:
        print(f"  [DRY-RUN] Would create Device: {name}  role={role_name}  type={dtype_name}  tenant={tenant_name}")
        return True

    result = nb.post("dcim/devices/", payload)
    if result.get("id"):
        print(f"  [OK] Device created: {name} (id={result['id']})")
        return True
    print(f"  [FAIL] Could not create Device: {name}")
    return False


def import_vm(row, cfg, nb: NetBoxAPI, dry_run: bool) -> bool:
    f = cfg["fields"]
    name = cell(row, f["name"]["excel_column"])
    if not name:
        print("  [SKIP] Empty VM name")
        return False

    existing_id = nb.get_vm_id(name)
    if existing_id:
        print(f"  [SKIP] VM already exists: {name} (id={existing_id})")
        return False

    role_name     = cell(row, f.get("role", {}).get("excel_column", ""))
    tenant_name   = cell(row, f.get("tenant", {}).get("excel_column", ""))
    platform_name = cell(row, f.get("platform", {}).get("excel_column", ""))
    status_col    = f.get("status", {}).get("excel_column", "")
    status        = cell(row, status_col) or f.get("status", {}).get("default", "active")

    role_id     = nb.get_role_id(role_name)         if role_name     else None
    tenant_id   = nb.get_tenant_id(tenant_name)     if tenant_name   else None
    platform_id = nb.get_platform_id(platform_name) if platform_name else None
    cluster_id  = nb.get_cluster_id(DEFAULT_VM_CLUSTER)

    if not cluster_id:
        print(f"  [WARN] Cluster '{DEFAULT_VM_CLUSTER}' not found in NetBox — cluster will be omitted for {name}")

    payload = {
        "name":          name,
        "status":        status.lower() if status else "active",
        "custom_fields": build_custom_fields(row, cfg),
    }
    if role_id:     payload["role"]    = role_id
    if tenant_id:   payload["tenant"]  = tenant_id
    if platform_id: payload["platform"] = platform_id
    if cluster_id:  payload["cluster"]  = cluster_id

    if dry_run:
        print(f"  [DRY-RUN] Would create VM: {name}  role={role_name}  tenant={tenant_name}")
        return True

    result = nb.post("virtualization/virtual-machines/", payload)
    if result.get("id"):
        print(f"  [OK] VM created: {name} (id={result['id']})")
        return True
    print(f"  [FAIL] Could not create VM: {name}")
    return False


def main():
    parser = argparse.ArgumentParser(description="Step 1 — Import Devices & VMs into NetBox")
    parser.add_argument("excel_file", help="Path to the consolidated Excel inventory")
    parser.add_argument("--mapping", default="mapping.yaml", help="Path to mapping.yaml")
    parser.add_argument("--dry-run", action="store_true", help="Preview without writing to NetBox")
    args = parser.parse_args()

    cfg = load_config(args.mapping)
    df  = load_excel(args.excel_file, cfg)
    nb  = NetBoxAPI(cfg)

    created_devices = created_vms = skipped = errors = 0

    for idx, row in df.iterrows():
        kind = get_kind(row, cfg)
        name = cell(row, cfg["fields"]["name"]["excel_column"])

        if kind is None:
            print(f"[SKIP row {idx+1}] '{name}' — unrecognized kind: {row.get(cfg['kind_column'], '?')}")
            skipped += 1
            continue

        print(f"\n[Row {idx+1}] {name}  ({kind.upper()})")

        if kind == "device":
            ok = import_device(row, cfg, nb, args.dry_run)
            if ok: created_devices += 1
            else:  errors += 1
        else:
            ok = import_vm(row, cfg, nb, args.dry_run)
            if ok: created_vms += 1
            else:  errors += 1

    print("\n" + "="*60)
    print(f"  Devices created : {created_devices}")
    print(f"  VMs created     : {created_vms}")
    print(f"  Skipped         : {skipped}")
    print(f"  Errors/existing : {errors}")
    print("="*60)
    if args.dry_run:
        print("  DRY-RUN — nothing was written to NetBox.")


if __name__ == "__main__":
    main()
