#!/usr/bin/env python3
"""
Step 3 — Import IP Addresses and assign them to Interfaces and Devices/VMs.

Run AFTER step 1 (devices/VMs) and step 2 (interfaces).

For each IP in the Excel column:
  1. Create the IP address object in NetBox (if it doesn't exist).
  2. Assign it to the device/VM interface.
  3. Set it as the primary IP of the device/VM (first IP only).

Usage:
    python 03_import_ips.py <excel_file> [--mapping mapping.yaml] [--dry-run]
"""

import sys
import argparse
from nb_utils import load_config, load_excel, get_kind, cell, parse_ips, NetBoxAPI


def get_or_create_ip(ip_cidr: str, nb: NetBoxAPI, dry_run: bool) -> int | None:
    """Return existing IP id or create it and return new id."""
    results = nb.get("ipam/ip-addresses/", {"address": ip_cidr})
    if results:
        ip_id = results[0]["id"]
        print(f"    [EXISTING] IP {ip_cidr} (id={ip_id})")
        return ip_id

    if dry_run:
        print(f"    [DRY-RUN] Would create IP: {ip_cidr}")
        return None

    result = nb.post("ipam/ip-addresses/", {"address": ip_cidr, "status": "active"})
    if result.get("id"):
        print(f"    [OK] IP created: {ip_cidr} (id={result['id']})")
        return result["id"]
    print(f"    [FAIL] Could not create IP: {ip_cidr}")
    return None


def assign_ip_to_device_interface(ip_id: int, device_id: int, iface_id: int,
                                   ip_cidr: str, nb: NetBoxAPI, dry_run: bool):
    if dry_run:
        print(f"    [DRY-RUN] Would assign IP {ip_cidr} to device interface id={iface_id}")
        return
    nb.patch("ipam/ip-addresses/", ip_id, {
        "assigned_object_type": "dcim.interface",
        "assigned_object_id":   iface_id,
    })
    print(f"    [OK] IP {ip_cidr} assigned to device interface id={iface_id}")


def assign_ip_to_vm_interface(ip_id: int, vm_id: int, iface_id: int,
                               ip_cidr: str, nb: NetBoxAPI, dry_run: bool):
    if dry_run:
        print(f"    [DRY-RUN] Would assign IP {ip_cidr} to VM interface id={iface_id}")
        return
    nb.patch("ipam/ip-addresses/", ip_id, {
        "assigned_object_type": "virtualization.vminterface",
        "assigned_object_id":   iface_id,
    })
    print(f"    [OK] IP {ip_cidr} assigned to VM interface id={iface_id}")


def set_primary_ip(device_id: int, ip_id: int, kind: str, ip_cidr: str,
                   nb: NetBoxAPI, dry_run: bool):
    """Set the first IP as the primary IP of the device/VM."""
    import ipaddress
    try:
        parsed = ipaddress.ip_interface(ip_cidr)
        field  = "primary_ip4" if parsed.version == 4 else "primary_ip6"
    except ValueError:
        field  = "primary_ip4"

    if dry_run:
        print(f"    [DRY-RUN] Would set {field}={ip_cidr} on {kind} id={device_id}")
        return

    if kind == "device":
        nb.patch("dcim/devices/", device_id, {field: ip_id})
    else:
        nb.patch("virtualization/virtual-machines/", device_id, {field: ip_id})
    print(f"    [OK] Set {field} = {ip_cidr} on {kind} id={device_id}")


def get_iface_name(row, cfg) -> str:
    iface_cfg = cfg.get("interface", {})
    name_col  = iface_cfg.get("name_column", "")
    val       = cell(row, name_col) if name_col else ""
    if val:
        return val
    kind = get_kind(row, cfg)
    if kind == "vm":
        return iface_cfg.get("default_vm_interface", "eth0")
    return iface_cfg.get("default_device_interface", "mgmt")


def main():
    parser = argparse.ArgumentParser(description="Step 3 — Import IPs into NetBox")
    parser.add_argument("excel_file", help="Path to the consolidated Excel inventory")
    parser.add_argument("--mapping", default="mapping.yaml", help="Path to mapping.yaml")
    parser.add_argument("--dry-run", action="store_true", help="Preview without writing")
    args = parser.parse_args()

    cfg = load_config(args.mapping)
    df  = load_excel(args.excel_file, cfg)
    nb  = NetBoxAPI(cfg)

    ip_col        = cfg.get("ip", {}).get("column", "IP Address(es)")
    default_prefix = cfg.get("ip", {}).get("prefix_length", "/24")

    created = assigned = skipped = errors = 0

    for idx, row in df.iterrows():
        kind = get_kind(row, cfg)
        name = cell(row, cfg["fields"]["name"]["excel_column"])

        if kind is None:
            skipped += 1
            continue

        raw_ips = cell(row, ip_col)
        if not raw_ips:
            print(f"\n[Row {idx+1}] {name} — no IPs, skipping")
            skipped += 1
            continue

        ips = parse_ips(raw_ips, default_prefix)
        if not ips:
            skipped += 1
            continue

        print(f"\n[Row {idx+1}] {name}  ({kind.upper()})  → {len(ips)} IP(s)")

        iface_name = get_iface_name(row, cfg)

        if kind == "device":
            obj_id   = nb.get_device_id(name)
            iface_id = nb.get_interface_id(obj_id, iface_name) if obj_id else None
        else:
            obj_id   = nb.get_vm_id(name)
            iface_id = nb.get_vm_interface_id(obj_id, iface_name) if obj_id else None

        if not obj_id:
            print(f"  [ERROR] {kind.capitalize()} '{name}' not found — run steps 1 & 2 first")
            errors += 1
            continue

        if not iface_id:
            print(f"  [ERROR] Interface '{iface_name}' not found on {kind} '{name}' — run step 2 first")
            errors += 1
            continue

        primary_set = False
        for ip_cidr in ips:
            ip_id = get_or_create_ip(ip_cidr, nb, args.dry_run)
            if not ip_id and not args.dry_run:
                errors += 1
                continue

            if kind == "device":
                assign_ip_to_device_interface(ip_id, obj_id, iface_id, ip_cidr, nb, args.dry_run)
            else:
                assign_ip_to_vm_interface(ip_id, obj_id, iface_id, ip_cidr, nb, args.dry_run)
            assigned += 1

            if not primary_set:
                set_primary_ip(obj_id, ip_id, kind, ip_cidr, nb, args.dry_run)
                primary_set = True

        created += len(ips)

    print("\n" + "="*60)
    print(f"  IPs processed : {created}")
    print(f"  Assignments   : {assigned}")
    print(f"  Skipped       : {skipped}")
    print(f"  Errors        : {errors}")
    print("="*60)
    if args.dry_run:
        print("  DRY-RUN — nothing was written to NetBox.")


if __name__ == "__main__":
    main()
