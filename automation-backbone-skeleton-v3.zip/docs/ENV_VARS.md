# Environment Variables

NetBox (required):
- NETBOX_URL
- NETBOX_TOKEN
Optional:
- NETBOX_VERIFY_SSL (true/false, default true)
- NETBOX_PAGE_SIZE (default 200)

Wazuh (required):
- WAZUH_URL
- WAZUH_USER
- WAZUH_PASSWORD
Optional:
- WAZUH_VERIFY_SSL (true/false, default false)
- WAZUH_PAGE_SIZE (default 500)
