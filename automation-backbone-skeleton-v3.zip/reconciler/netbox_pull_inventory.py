#!/usr/bin/env python3
"""NetBox Inventory Puller (implemented)

Pulls Devices + Virtual Machines from NetBox via REST API (pagination supported).
Outputs normalized inventory JSON for reconciliation.

Required env vars:
  - NETBOX_URL  (e.g. https://netbox.example.com)
  - NETBOX_TOKEN (API token)

Optional:
  - NETBOX_VERIFY_SSL (true/false, default true)
  - NETBOX_PAGE_SIZE (default 200)

Notes:
- This produces a reference inventory (allowed assets). `last_seen` is set to pull time.
- It attempts to populate `uuid` from common custom-field names if present.
"""
import argparse
import os
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional
import requests

from collectors.common.io import write_json
from collectors.common.normalize import make_record, iso_utc

def env_bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1","true","yes","y","on")

def get_required(name: str) -> str:
    v = os.getenv(name)
    if not v or not str(v).strip():
        raise SystemExit(f"Missing required env var: {name}")
    return v.strip()

def safe_get(obj: Dict[str, Any], path: str) -> Any:
    cur: Any = obj
    for part in path.split("."):
        if cur is None:
            return None
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
    return cur

def guess_uuid(custom_fields: Dict[str, Any]) -> Optional[str]:
    if not isinstance(custom_fields, dict):
        return None
    for k in ("uuid", "vm_uuid", "instance_uuid", "bios_uuid", "agent_id", "wazuh_agent_id"):
        v = custom_fields.get(k)
        if v:
            return str(v).strip()
    return None

def get_primary_ip(result: Dict[str, Any]) -> Optional[str]:
    addr = safe_get(result, "primary_ip4.address") or safe_get(result, "primary_ip6.address")
    if not addr:
        return None
    return str(addr).split("/")[0]

def paginate(session: requests.Session, url: str, params: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
    next_url = url
    while next_url:
        r = session.get(next_url, params=params if next_url == url else None)
        r.raise_for_status()
        data = r.json()
        for item in data.get("results", []):
            yield item
        next_url = data.get("next")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="artifacts/inventory/netbox.json")
    ap.add_argument("--include-devices", action="store_true", default=True)
    ap.add_argument("--include-vms", action="store_true", default=True)
    ap.add_argument("--only-active", action="store_true", default=False)
    args = ap.parse_args()

    base_url = get_required("NETBOX_URL").rstrip("/")
    token = get_required("NETBOX_TOKEN")
    verify_ssl = env_bool("NETBOX_VERIFY_SSL", True)
    page_size = int(os.getenv("NETBOX_PAGE_SIZE", "200"))

    s = requests.Session()
    s.verify = verify_ssl
    s.headers.update({
        "Authorization": f"Token {token}",
        "Accept": "application/json",
        "User-Agent": "automation-backbone/1.0 netbox-puller"
    })

    pulled_at = iso_utc(datetime.now(timezone.utc))
    assets: List[Dict[str, Any]] = []

    if args.include_devices:
        url = f"{base_url}/api/dcim/devices/"
        params = {"limit": page_size}
        if args.only_active:
            params["status"] = "active"
        for d in paginate(s, url, params):
            cf = d.get("custom_fields") or {}
            assets.append(make_record(
                source="netbox",
                asset_type="device",
                raw_id=d.get("id") or d.get("url") or d.get("name") or "unknown",
                hostname=d.get("name"),
                fqdn=cf.get("fqdn") or cf.get("FQDN"),
                ip=get_primary_ip(d),
                serial=d.get("serial"),
                uuid=guess_uuid(cf),
                os=safe_get(d, "platform.name") or cf.get("os"),
                last_seen=pulled_at,
                confidence=1.0,
                tags=[
                    *( [f"status:{safe_get(d,'status.value')}"] if safe_get(d,'status.value') else [] ),
                    *( [f"role:{safe_get(d,'role.slug')}"] if safe_get(d,'role.slug') else [] ),
                    *( [f"site:{safe_get(d,'site.slug')}"] if safe_get(d,'site.slug') else [] ),
                ],
                raw={
                    "netbox_type": "device",
                    "name": d.get("name"),
                    "status": safe_get(d, "status.value"),
                    "role": safe_get(d, "role.name"),
                    "site": safe_get(d, "site.name"),
                    "tenant": safe_get(d, "tenant.name"),
                    "primary_ip4": safe_get(d, "primary_ip4.address"),
                    "primary_ip6": safe_get(d, "primary_ip6.address"),
                    "custom_fields": cf,
                }
            ))

    if args.include_vms:
        url = f"{base_url}/api/virtualization/virtual-machines/"
        params = {"limit": page_size}
        if args.only_active:
            params["status"] = "active"
        for v in paginate(s, url, params):
            cf = v.get("custom_fields") or {}
            assets.append(make_record(
                source="netbox",
                asset_type="vm",
                raw_id=v.get("id") or v.get("url") or v.get("name") or "unknown",
                hostname=v.get("name"),
                fqdn=cf.get("fqdn") or cf.get("FQDN"),
                ip=get_primary_ip(v),
                serial=cf.get("serial") or None,
                uuid=guess_uuid(cf),
                os=safe_get(v, "platform.name") or cf.get("os"),
                last_seen=pulled_at,
                confidence=1.0,
                tags=[
                    *( [f"status:{safe_get(v,'status.value')}"] if safe_get(v,'status.value') else [] ),
                    *( [f"cluster:{safe_get(v,'cluster.name')}"] if safe_get(v,'cluster.name') else [] ),
                    *( [f"site:{safe_get(v,'site.slug')}"] if safe_get(v,'site.slug') else [] ),
                ],
                raw={
                    "netbox_type": "vm",
                    "name": v.get("name"),
                    "status": safe_get(v, "status.value"),
                    "cluster": safe_get(v, "cluster.name"),
                    "site": safe_get(v, "site.name"),
                    "tenant": safe_get(v, "tenant.name"),
                    "primary_ip4": safe_get(v, "primary_ip4.address"),
                    "primary_ip6": safe_get(v, "primary_ip6.address"),
                    "custom_fields": cf,
                }
            ))

    write_json(args.out, assets)
    print(f"NetBox pulled assets: {len(assets)} -> {args.out} (pulled_at={pulled_at})")

if __name__ == "__main__":
    main()
