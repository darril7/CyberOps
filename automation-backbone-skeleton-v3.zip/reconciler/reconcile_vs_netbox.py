#!/usr/bin/env python3
"""Reconcile tool inventories vs NetBox (implemented)

Reads:
- artifacts/inventory/netbox.json (reference inventory pulled from NetBox)
- artifacts/inventory/<source>.json for each collector output

Produces:
- artifacts/reports/matched_assets.csv
- artifacts/reports/unknown_assets.csv
- artifacts/reports/stale_assets.csv
- artifacts/reports/conflicts.csv (placeholder)

This uses per-collector match_priority from collectors_manifest.yml.
"""
import argparse
from pathlib import Path
import csv
import yaml
from datetime import datetime, timezone, timedelta

from collectors.common.io import read_json
from reconciler.match import build_index, match_one

REPO_ROOT = Path(__file__).resolve().parents[1]
MANIFEST = REPO_ROOT / "collectors_manifest.yml"

def load_manifest():
    return yaml.safe_load(MANIFEST.read_text(encoding="utf-8"))

def parse_iso(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z","+00:00")).astimezone(timezone.utc)

def write_csv(path: Path, rows: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-dir", default="artifacts/inventory")
    ap.add_argument("--out-dir", default="artifacts/reports")
    ap.add_argument("--match-hierarchy", default="", help="Override global match hierarchy (comma-separated)")
    args = ap.parse_args()

    m = load_manifest()
    in_dir = REPO_ROOT / args.in_dir
    out_dir = REPO_ROOT / args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    netbox_path = in_dir / "netbox.json"
    if not netbox_path.exists():
        raise SystemExit(f"Missing NetBox reference inventory: {netbox_path} (run netbox_pull first)")
    netbox_assets = read_json(netbox_path)

    global_hierarchy = m["reconciliation"]["match_hierarchy"]
    if args.match_hierarchy.strip():
        global_hierarchy = [x.strip() for x in args.match_hierarchy.split(",") if x.strip()]

    idx = build_index(netbox_assets, global_hierarchy)

    matched, unknown, stale, conflicts = [], [], [], []
    now = datetime.now(timezone.utc)

    for c in m["collectors"]:
        if c["id"] == "netbox_pull":
            continue
        out_name = Path(c["output"]).name  # e.g., wazuh.json
        p = in_dir / out_name
        if not p.exists():
            continue

        assets = read_json(p)
        stale_days = int(c.get("stale_days_default", 30))
        stale_cutoff = now - timedelta(days=stale_days)
        priority = c.get("match_priority") or global_hierarchy

        for a in assets:
            try:
                last_seen_dt = parse_iso(a.get("last_seen",""))
            except Exception:
                last_seen_dt = None

            nb = match_one(a, idx, priority)
            row = {
                "source": a.get("source"),
                "raw_id": a.get("raw_id"),
                "hostname": a.get("hostname"),
                "fqdn": a.get("fqdn"),
                "ip": a.get("ip"),
                "mac": a.get("mac"),
                "serial": a.get("serial"),
                "uuid": a.get("uuid"),
                "last_seen": a.get("last_seen"),
                "netbox_match": (nb or {}).get("hostname") or (nb or {}).get("fqdn") or "",
            }

            if last_seen_dt and last_seen_dt < stale_cutoff:
                stale.append({**row, "stale_days": stale_days})
            if nb:
                matched.append(row)
            else:
                unknown.append(row)

    write_csv(out_dir / "matched_assets.csv", matched)
    write_csv(out_dir / "unknown_assets.csv", unknown)
    write_csv(out_dir / "stale_assets.csv", stale)
    write_csv(out_dir / "conflicts.csv", conflicts)

    print(f"Matched: {len(matched)} | Unknown: {len(unknown)} | Stale: {len(stale)}")
    print(f"Reports written to: {out_dir}")

if __name__ == "__main__":
    main()
