from typing import Any, Dict, Iterable, Optional, Tuple

def _first(v):
    return v if v not in (None, "", []) else None

def key_variants(asset: Dict[str, Any]) -> Dict[str, Optional[str]]:
    return {
        "uuid": _first(asset.get("uuid")),
        "serial": _first(asset.get("serial")),
        "mac": _first(asset.get("mac")),
        "ip": _first(asset.get("ip")),
        "fqdn": _first(asset.get("fqdn")),
        "hostname": _first(asset.get("hostname")),
    }

def build_index(assets: Iterable[Dict[str, Any]], fields: list[str]) -> Dict[Tuple[str,str], Dict[str, Any]]:
    idx: Dict[Tuple[str,str], Dict[str, Any]] = {}
    for a in assets:
        kv = key_variants(a)
        for f in fields:
            val = kv.get(f)
            if val:
                idx[(f, val)] = a
    return idx

def match_one(asset: Dict[str, Any], idx: Dict[Tuple[str,str], Dict[str, Any]], priority: list[str]) -> Optional[Dict[str, Any]]:
    kv = key_variants(asset)
    for f in priority:
        val = kv.get(f)
        if not val:
            continue
        m = idx.get((f, val))
        if m:
            return m
    return None
