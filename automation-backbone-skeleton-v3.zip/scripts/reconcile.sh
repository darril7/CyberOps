#!/usr/bin/env bash
set -euo pipefail
python3 reconciler/reconcile_vs_netbox.py --in-dir artifacts/inventory --out-dir artifacts/reports
