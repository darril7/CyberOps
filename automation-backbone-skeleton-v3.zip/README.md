# automation-backbone

Collectors + reconciler to:
- Pull inventories from consoles (WSUS/Wazuh/etc.)
- Normalize into a common schema
- Reconcile vs NetBox (SoT) to find unknown/stale assets

## Quick start
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

export NETBOX_URL="https://netbox.example.com"
export NETBOX_TOKEN="..."
python3 reconciler/netbox_pull_inventory.py --out artifacts/inventory/netbox.json

export WAZUH_URL="https://wazuh-manager:55000"
export WAZUH_USER="..."
export WAZUH_PASSWORD="..."
python3 collectors/wazuh/collect_wazuh_inventory.py --out artifacts/inventory/wazuh.json

python3 reconciler/reconcile_vs_netbox.py --in-dir artifacts/inventory --out-dir artifacts/reports
```

## Outputs
- artifacts/reports/unknown_assets.csv
- artifacts/reports/matched_assets.csv
- artifacts/reports/stale_assets.csv
