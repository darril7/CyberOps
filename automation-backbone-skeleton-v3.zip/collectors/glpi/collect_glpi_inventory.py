#!/usr/bin/env python3
"""GLPI API Collector (skeleton)

TODO: Implement API calls and normalization.
"""
import argparse
from datetime import datetime, timezone
from collectors.common.io import write_json
from collectors.common.normalize import make_record, iso_utc

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="artifacts/inventory/glpi.json")
    args = ap.parse_args()
    now = iso_utc(datetime.now(timezone.utc))
    recs = [make_record(source="glpi", asset_type="unknown", raw_id="example", hostname="example", last_seen=now, raw={"note":"skeleton"})]
    write_json(args.out, recs)
    print(f"Wrote {len(recs)} records to {args.out}")

if __name__ == "__main__":
    main()
