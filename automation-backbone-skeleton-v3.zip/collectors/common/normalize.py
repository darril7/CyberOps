import re
from datetime import datetime, timezone
from typing import Any, Dict, Optional

_host_strip_re = re.compile(r"[^a-z0-9\-_.]")

def iso_utc(dt: datetime) -> str:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")

def parse_dt_any(value: Any) -> Optional[str]:
    """Best-effort datetime parsing. Return ISO-8601 Z or None."""
    if value is None:
        return None
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y %H:%M:%S"):
            try:
                dt = datetime.strptime(s, fmt)
                return iso_utc(dt.replace(tzinfo=timezone.utc))
            except Exception:
                pass
        try:
            dt = datetime.fromisoformat(s.replace("Z","+00:00"))
            return iso_utc(dt)
        except Exception:
            return None
    if isinstance(value, (int, float)):
        try:
            return iso_utc(datetime.fromtimestamp(value, tz=timezone.utc))
        except Exception:
            return None
    if isinstance(value, datetime):
        return iso_utc(value)
    return None

def norm_hostname(hostname: Optional[str], strip_domain: bool = True) -> Optional[str]:
    if not hostname:
        return None
    h = hostname.strip().lower()
    if strip_domain and "." in h:
        h = h.split(".")[0]
    h = _host_strip_re.sub("", h)
    return h or None

def norm_fqdn(fqdn: Optional[str]) -> Optional[str]:
    if not fqdn:
        return None
    f = fqdn.strip().lower()
    f = _host_strip_re.sub("", f)
    return f or None

def norm_ip(ip: Optional[str]) -> Optional[str]:
    if not ip:
        return None
    return ip.strip()

def norm_mac(mac: Optional[str]) -> Optional[str]:
    if not mac:
        return None
    m = mac.strip().lower().replace("-",":")
    return m

def make_record(
    *,
    source: str,
    raw_id: str,
    last_seen: str,
    asset_type: str = "unknown",
    hostname: Optional[str] = None,
    fqdn: Optional[str] = None,
    ip: Optional[str] = None,
    mac: Optional[str] = None,
    serial: Optional[str] = None,
    uuid: Optional[str] = None,
    os: Optional[str] = None,
    confidence: float = 0.0,
    tags: Optional[list[str]] = None,
    raw: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    return {
        "source": source,
        "asset_type": asset_type,
        "hostname": norm_hostname(hostname),
        "fqdn": norm_fqdn(fqdn),
        "ip": norm_ip(ip),
        "mac": norm_mac(mac),
        "serial": serial.strip() if isinstance(serial, str) and serial.strip() else serial,
        "uuid": uuid.strip() if isinstance(uuid, str) and uuid.strip() else uuid,
        "os": os,
        "last_seen": last_seen,
        "raw_id": str(raw_id),
        "confidence": float(confidence),
        "tags": tags or [],
        "raw": raw or {},
    }
