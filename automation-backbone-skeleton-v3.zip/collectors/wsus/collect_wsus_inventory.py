#!/usr/bin/env python3
"""WSUS Export Normalizer

Reads a WSUS export JSON (produced by Export-WsusClients.ps1) and writes normalized inventory.
"""
import argparse
from collectors.common.io import read_json, write_json
from collectors.common.normalize import make_record, parse_dt_any

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True, help="WSUS export JSON path")
    ap.add_argument("--out", default="artifacts/inventory/wsus.json", help="Output normalized JSON path")
    args = ap.parse_args()

    data = read_json(args.inp)
    recs = []
    for item in data:
        last_seen = parse_dt_any(item.get("last_seen") or item.get("LastReportedStatusTime")) or None
        if not last_seen:
            continue
        recs.append(make_record(
            source="wsus",
            asset_type="device",
            raw_id=item.get("raw_id") or item.get("ComputerTargetId") or item.get("id") or "unknown",
            hostname=item.get("hostname") or item.get("name"),
            fqdn=item.get("fqdn") or item.get("FullDomainName"),
            ip=item.get("ip"),
            os=item.get("os") or item.get("OSDescription"),
            last_seen=last_seen,
            raw={"wsus": item}
        ))
    write_json(args.out, recs)
    print(f"Wrote {len(recs)} records to {args.out}")

if __name__ == "__main__":
    main()
