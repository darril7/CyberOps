\
param(
  [Parameter(Mandatory=$false)]
  [string]$OutPath = "C:\Temp\wsus_clients.json"
)

# Skeleton export. Replace with real WSUS calls on WSUS server.
# Goal: export array of objects with raw_id, fqdn/hostname, ip(optional), last_seen, os(optional)

$example = @(
  [PSCustomObject]@{
    raw_id    = "example-wsus-id"
    fqdn      = "example-host.domain.local"
    ip        = "10.0.0.10"
    last_seen = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    os        = "Windows"
  }
)

$example | ConvertTo-Json -Depth 5 | Out-File -FilePath $OutPath -Encoding utf8
Write-Host "Wrote WSUS export to $OutPath"
