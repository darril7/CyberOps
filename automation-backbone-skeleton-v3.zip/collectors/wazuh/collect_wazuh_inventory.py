#!/usr/bin/env python3
"""Wazuh API Collector (implemented)

Pulls agent inventory from Wazuh API and outputs normalized inventory JSON.

Required env vars:
  - WAZUH_URL        (e.g. https://wazuh-manager:55000)
  - WAZUH_USER
  - WAZUH_PASSWORD

Optional env vars:
  - WAZUH_VERIFY_SSL (true/false, default false)
  - WAZUH_PAGE_SIZE  (default 500)

Output:
  - artifacts/inventory/wazuh.json (or --out)

Matching priority (per manifest): uuid(agent_id) -> hostname -> ip -> fqdn
"""
import argparse
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
import requests

from collectors.common.io import write_json
from collectors.common.normalize import make_record, parse_dt_any, iso_utc, norm_hostname, norm_fqdn

def env_bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1","true","yes","y","on")

def get_required(name: str) -> str:
    v = os.getenv(name)
    if not v or not str(v).strip():
        raise SystemExit(f"Missing required env var: {name}")
    return v.strip()

def _pick_last_seen(agent: Dict[str, Any]) -> Optional[str]:
    for k in ("lastKeepAlive", "last_keep_alive", "lastSeen", "last_seen", "last_login", "dateLastSeen", "dateLastKeepAlive"):
        dt = parse_dt_any(agent.get(k))
        if dt:
            return dt
    return None

def _extract_identity(agent: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    name = agent.get("name") or agent.get("hostname") or agent.get("node_name")
    if isinstance(name, str) and "." in name:
        return (norm_hostname(name), norm_fqdn(name))
    return (norm_hostname(name), None)

def authenticate(base_url: str, user: str, password: str, verify_ssl: bool) -> str:
    url = f"{base_url.rstrip('/')}/security/user/authenticate"
    r = requests.post(url, auth=(user, password), verify=verify_ssl, headers={"Accept": "application/json"})
    r.raise_for_status()
    data = r.json()
    token = (data.get("data") or {}).get("token") or data.get("token")
    if not token:
        raise RuntimeError("Failed to obtain Wazuh token from /security/user/authenticate response.")
    return token

def get_agents(base_url: str, token: str, verify_ssl: bool, page_size: int) -> List[Dict[str, Any]]:
    s = requests.Session()
    s.verify = verify_ssl
    s.headers.update({
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "User-Agent": "automation-backbone/1.0 wazuh-collector"
    })

    agents: List[Dict[str, Any]] = []
    offset = 0
    endpoint = f"{base_url.rstrip('/')}/agents"
    params_base = {
        "limit": page_size,
        "offset": 0,
        "select": "id,name,ip,lastKeepAlive,dateAdd,version,os,manager,status,group"
    }

    while True:
        params = dict(params_base)
        params["offset"] = offset
        r = s.get(endpoint, params=params)
        r.raise_for_status()
        payload = r.json()

        data = payload.get("data") or payload
        items = data.get("affected_items") or data.get("items") or data.get("agents") or []
        if not isinstance(items, list):
            raise RuntimeError("Unexpected Wazuh agents response format (items is not a list).")

        agents.extend(items)

        total = data.get("total_affected_items") or data.get("totalItems") or data.get("total") or None
        if total is None:
            if len(items) < page_size:
                break
        else:
            try:
                total_int = int(total)
            except Exception:
                total_int = None
            if total_int is not None and (offset + page_size) >= total_int:
                break

        if len(items) == 0:
            break
        offset += page_size

    return agents

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="artifacts/inventory/wazuh.json", help="Output JSON path")
    args = ap.parse_args()

    base_url = get_required("WAZUH_URL")
    user = get_required("WAZUH_USER")
    password = get_required("WAZUH_PASSWORD")
    verify_ssl = env_bool("WAZUH_VERIFY_SSL", False)
    page_size = int(os.getenv("WAZUH_PAGE_SIZE", "500"))

    token = authenticate(base_url, user, password, verify_ssl)
    agents = get_agents(base_url, token, verify_ssl, page_size)

    now_iso = iso_utc(datetime.now(timezone.utc))
    recs: List[Dict[str, Any]] = []

    for a in agents:
        agent_id = a.get("id") or a.get("agent_id") or a.get("uuid") or a.get("raw_id")
        if agent_id is None:
            continue

        hostname, fqdn = _extract_identity(a)
        ip = a.get("ip") or a.get("agent_ip")
        last_seen = _pick_last_seen(a) or now_iso

        os_name = None
        os_obj = a.get("os")
        if isinstance(os_obj, dict):
            os_name = os_obj.get("name") or os_obj.get("platform") or os_obj.get("version")
        elif isinstance(os_obj, str):
            os_name = os_obj

        tags = []
        status = a.get("status")
        if status:
            tags.append(f"status:{status}")
        manager = a.get("manager")
        if manager:
            tags.append(f"manager:{manager}")
        group = a.get("group") or a.get("groups")
        if isinstance(group, str) and group:
            tags.append(f"group:{group}")
        elif isinstance(group, list):
            for g in group:
                if g:
                    tags.append(f"group:{g}")

        recs.append(make_record(
            source="wazuh",
            asset_type="device",
            raw_id=str(agent_id),
            uuid=str(agent_id),
            hostname=hostname,
            fqdn=fqdn,
            ip=ip,
            os=os_name,
            last_seen=last_seen,
            confidence=0.9,
            tags=tags,
            raw={"wazuh_agent": a}
        ))

    write_json(args.out, recs)
    print(f"Wazuh pulled agents: {len(recs)} -> {args.out}")

if __name__ == "__main__":
    main()
